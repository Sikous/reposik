
package ukol3.FileInputOutput;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 *
 * @author Sikora Jan P21101
 * 
 */
public class FileIO {

    private File sifrFile, desifrFile;

  
    public void setdesifrFile(File newFile) {
        this.desifrFile = newFile;
    }

    public void setdeisfrFile(Path path) {
        this.desifrFile = new File(path.toString());
    }

    
    public void setsifrFile(File newFile) {
        this.sifrFile = newFile;
    }

 
    public void setsifrFile(Path path) {
        this.sifrFile = new File(path.toString());
    }

 
    public File getdesifrFile() {
        return this.desifrFile;
    }

   
    public File getsifrFile() {
        return this.sifrFile;
    }

   
    public void cisto() {
        this.desifrFile = null;
        this.sifrFile = null;
    }
    
    public boolean zasifrovan(File file) {
        
        return file.getName().endsWith("aes");
    }

    public boolean jeSifr(Path path) { //prida koncovku aes
        return path.endsWith("aes");
    }
    public boolean jeValid(Path path){   
        return (Files.exists(path) && !Files.isDirectory(path));
    }

}
