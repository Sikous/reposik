package ukol3.sifrovani;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;


import java.security.AlgorithmParameters;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import javax.crypto.*;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;

import ukol3.FileInputOutput.FileIO;


/**

 * @author Sikora Jan P21101
 */
public class Sifrovani {

    static FileIO fio;
    //nadefinovani aesu 128
    private static final String ALG = "AES";
    private static final String CIPH = "AES/CBC/PKCS5Padding";
    private static final String CIPH2 = "AES/CFB/PKCS5Padding";
    private static final String KEYFAC = "PBKDF2WithHmacSHA1";

   //sifrovani samotne
    public static String zasifruj(File file, String password, String mode) throws Exception {
        FileOutputStream souborek;
        try (
                FileInputStream inFile = new FileInputStream(file)) {
            souborek = new FileOutputStream(file + ".aes");

            byte[] s = new byte[8];
            SecureRandom secureRandom = new SecureRandom();
            secureRandom.nextBytes(s);

            souborek.write(s);

            //generuje 128 klič
            SecretKeyFactory factory = SecretKeyFactory
                    .getInstance(KEYFAC);
            KeySpec keySpec = new PBEKeySpec(password.toCharArray(), s, 65536,
                    128);
            SecretKey secretKey = factory.generateSecret(keySpec);
            SecretKey secret = new SecretKeySpec(secretKey.getEncoded(), ALG);

            // inicializuje šifru
          
   
System.out.println("tohle je mode na zacatku sifrovani "+mode+"tu konci");
    int cislo = Integer.parseInt(mode);


	if(cislo==1){
        
            Cipher c = Cipher.getInstance(CIPH);
            c.init(Cipher.ENCRYPT_MODE, secret);
            AlgorithmParameters p = c.getParameters();
            // zde se genruje inicializační vektor odkaz na  popis metody getIV() http://www.java2s.com/example/java-utility-method/iv-generate/generateiv-77e61.html
            byte[] iv = p.getParameterSpec(IvParameterSpec.class).getIV();

            souborek.write(iv);

            //zašifruje soubor
            byte[] vstup = new byte[64];
            int bytesRead;
            while ((bytesRead = inFile.read(vstup)) != -1) {
                byte[] vystup = c.update(vstup, 0, bytesRead);
                if (vystup != null) {
                    souborek.write(vystup);
                }
            }
            byte[] vystup = c.doFinal();
            if (vystup!= null) {
                souborek.write(vystup);
            }
        

        souborek.flush();
        souborek.close();

    }
    System.out.println("Totoje sifrovaci promena mode"+ mode);
    if(cislo==2){
        Cipher c = Cipher.getInstance(CIPH2);
        c.init(Cipher.ENCRYPT_MODE, secret);
        AlgorithmParameters p = c.getParameters();
        byte[] iv = p.getParameterSpec(IvParameterSpec.class).getIV();

        //vystup dava do streamu na vystup
        souborek.write(iv);

        //zašifruje soubor
        byte[] vstup = new byte[64];
        int bytesRead;
        while ((bytesRead = inFile.read(vstup)) != -1) {
            byte[] vystup = c.update(vstup, 0, bytesRead);
            if (vystup != null) {
                souborek.write(vystup);
            }
        }
        byte[] vystup = c.doFinal();
        if (vystup!= null) {
            souborek.write(vystup);
        }
    

    souborek.flush();
    souborek.close();
    }

        return file + ".aes"; // prida priponu aes at se lepe hleda mezi soubory
    
    }
}
}
